import "./GamePanel.scss";
export const GamePanel = () => {
  return <section className="panel"></section>;
};
