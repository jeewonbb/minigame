import "./PanelBtn.scss";
export const PanelBtn = () => {
  return <button type="button" className="btn-panel-slide"></button>;
};
